/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ec.edu.uees.proyectodistribuidos1;

/**
 *
 * @author PC-HOME
 */
public class barcoP extends Barco  implements java.io.Serializable {
    
    public barcoP() {
        super(2);
    }
    
}
